#!/usr/bin/env python3
import os
import requests

API = "https://api.openweathermap.org/data/2.5/weather"

def get_api_key():
    key = os.getenv("OPENWEATHER_API_KEY")
    if not key:
        print("Enter your OpenWeather API key (create free at openweathermap.org):")
        key = input("> ").strip()
    return key

def kelvin_to_celsius(k): return k - 273.15

def main():
    city = input("Enter city name (e.g., London): ").strip()
    key = get_api_key()
    params = {"q": city, "appid": key}
    try:
        r = requests.get(API, params=params, timeout=10)
        r.raise_for_status()
        data = r.json()
        name = data.get("name")
        temp_c = kelvin_to_celsius(data["main"]["temp"])
        weather = data["weather"][0]["description"].title()
        print(f"Weather in {name}: {weather}, {temp_c:.1f}°C")
    except requests.HTTPError as e:
        if r.status_code == 401:
            print("Invalid API key. Set OPENWEATHER_API_KEY env var or re-enter.")
        else:
            print("HTTP error:", e)
    except Exception as e:
        print("Error fetching weather:", e)

if __name__ == "__main__":
    main()