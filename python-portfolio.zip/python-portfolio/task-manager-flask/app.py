#!/usr/bin/env python3
from flask import Flask, render_template, request, redirect, url_for
import sqlite3

DB = 'tasks.db'
app = Flask(__name__)

def init_db():
    with sqlite3.connect(DB) as con:
        con.execute('CREATE TABLE IF NOT EXISTS tasks (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL)')

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        title = request.form.get('title','').strip()
        if title:
            with sqlite3.connect(DB) as con:
                con.execute('INSERT INTO tasks (title) VALUES (?)', (title,))
        return redirect(url_for('index'))
    with sqlite3.connect(DB) as con:
        tasks = con.execute('SELECT id, title FROM tasks ORDER BY id DESC').fetchall()
    return render_template('index.html', tasks=tasks)

@app.post('/delete/<int:task_id>')
def delete(task_id):
    with sqlite3.connect(DB) as con:
        con.execute('DELETE FROM tasks WHERE id=?', (task_id,))
    return redirect(url_for('index'))

if __name__ == '__main__':
    init_db()
    app.run(debug=True)