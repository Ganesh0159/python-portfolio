#!/usr/bin/env python3
import os
import shutil
from pathlib import Path

def batch_rename(folder, prefix='file_', start=1, move_to=None):
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    if move_to:
        move_to = Path(move_to); move_to.mkdir(parents=True, exist_ok=True)
    i = start
    for p in sorted(folder.iterdir()):
        if p.is_file():
            new_name = f"{prefix}{i}{p.suffix}"
            target = folder / new_name
            p.rename(target)
            if move_to:
                shutil.move(str(target), str(move_to / new_name))
            i += 1
    print(f"Renamed files from {start} to {i-1}.")

if __name__ == '__main__':
    print("Batch Rename Utility") 
    f = input("Folder path: ").strip()
    prefix = input("Prefix (default 'file_'): ").strip() or 'file_'
    start = input("Start number (default 1): ").strip()
    start = int(start) if start.isdigit() else 1
    move = input("Move renamed files to another folder? (leave blank to skip): ").strip() or None
    batch_rename(f, prefix, start, move)