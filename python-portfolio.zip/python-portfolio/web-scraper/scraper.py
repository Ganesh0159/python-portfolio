#!/usr/bin/env python3
import csv
import requests
from bs4 import BeautifulSoup

BASE = "https://quotes.toscrape.com"
OUTFILE = "quotes.csv"

def scrape_page(url):
    r = requests.get(url, timeout=10)
    r.raise_for_status()
    soup = BeautifulSoup(r.text, "html.parser")
    quotes = []
    for q in soup.select(".quote"):
        text = q.select_one(".text").get_text(strip=True)
        author = q.select_one(".author").get_text(strip=True)
        tags = [t.get_text(strip=True) for t in q.select(".tags .tag")]
        quotes.append((text, author, ", ".join(tags)))
    next_link = soup.select_one("li.next a")
    next_url = BASE + next_link["href"] if next_link else None
    return quotes, next_url

def main():
    url = BASE
    all_rows = [("quote", "author", "tags")]
    while url:
        rows, url = scrape_page(url)
        all_rows.extend(rows)
        print(f"Scraped {len(rows)} quotes ...")
    with open(OUTFILE, "w", newline="", encoding="utf-8") as f:
        csv.writer(f).writerows(all_rows)
    print(f"Saved {len(all_rows)-1} quotes to {OUTFILE}")

if __name__ == "__main__":
    main()