# Python Developer Portfolio

Welcome to my Python development portfolio! 🚀 This repository showcases several beginner-to-intermediate projects demonstrating skills in Python programming, APIs, data analysis, web scraping, automation, and web development.

## 📂 Projects

1. **Calculator CLI** — fundamentals, functions, error handling.  
   - `calculator-cli/calculator.py`

2. **Weather App (API Integration)** — REST APIs and JSON.  
   - `weather-app/weather.py` (uses OpenWeather)  
   - `weather-app/requirements.txt`

3. **Web Scraper** — BeautifulSoup, requests, CSV export.  
   - `web-scraper/scraper.py`  
   - `web-scraper/requirements.txt`

4. **Data Analysis Project** — Pandas + Matplotlib on Titanic sample.  
   - `data-analysis/analysis.ipynb`  
   - `data-analysis/titanic_sample.csv`

5. **Task Manager (Flask App)** — CRUD with Flask + SQLite.  
   - `task-manager-flask/app.py`  
   - `task-manager-flask/templates/index.html`  
   - `task-manager-flask/requirements.txt`

6. **File Automation Script** — batch renaming/organizing files.  
   - `file-automation/rename_files.py`

## 🔧 Quick Start

```bash
# clone repo
git clone https://github.com/YOUR-USERNAME/python-portfolio.git
cd python-portfolio

# run calculator
python3 calculator-cli/calculator.py

# run weather app
pip install -r weather-app/requirements.txt
python3 weather-app/weather.py

# run scraper
pip install -r web-scraper/requirements.txt
python3 web-scraper/scraper.py

# run flask task manager
pip install -r task-manager-flask/requirements.txt
python3 task-manager-flask/app.py  # open http://127.0.0.1:5000

# open data analysis notebook
pip install pandas matplotlib jupyter
jupyter notebook data-analysis/analysis.ipynb
```

---

## 📌 Sharing
Once this is pushed to GitHub, share:
```
https://github.com/YOUR-USERNAME/python-portfolio
```
Replace `YOUR-USERNAME` with your GitHub username.