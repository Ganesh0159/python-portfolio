#!/usr/bin/env python3
import math

MENU = """
Simple Calculator
-----------------
1) Add
2) Subtract
3) Multiply
4) Divide
5) Power (x^y)
6) Square Root
7) Factorial
8) Percentage (part of whole)
9) Exit
"""

def read_float(prompt):
    while True:
        try:
            return float(input(prompt))
        except ValueError:
            print("Please enter a valid number.")

def add(a,b): return a+b
def sub(a,b): return a-b
def mul(a,b): return a*b
def div(a,b):
    if b == 0:
        raise ZeroDivisionError("Division by zero is not allowed.")
    return a/b

def main():
    while True:
        print(MENU)
        choice = input("Choose an option (1-9): ").strip()
        try:
            if choice == "1":
                a, b = read_float("A: "), read_float("B: ")
                print("Result:", add(a,b))
            elif choice == "2":
                a, b = read_float("A: "), read_float("B: ")
                print("Result:", sub(a,b))
            elif choice == "3":
                a, b = read_float("A: "), read_float("B: ")
                print("Result:", mul(a,b))
            elif choice == "4":
                a, b = read_float("A: "), read_float("B: ")
                print("Result:", div(a,b))
            elif choice == "5":
                a, b = read_float("Base: "), read_float("Exponent: ")
                print("Result:", math.pow(a,b))
            elif choice == "6":
                a = read_float("Number: ")
                if a < 0:
                    print("Cannot take square root of negative numbers.")
                else:
                    print("Result:", math.sqrt(a))
            elif choice == "7":
                n = read_float("Non-negative integer: ")
                if n < 0 or int(n) != n:
                    print("Please enter a non-negative integer for factorial.")
                else:
                    print("Result:", math.factorial(int(n)))
            elif choice == "8":
                part = read_float("Part: ")
                whole = read_float("Whole: ")
                if whole == 0:
                    print("Whole cannot be zero.")
                else:
                    print(f"Result: { (part/whole)*100 } %")
            elif choice == "9":
                print("Goodbye!")
                break
            else:
                print("Invalid option. Please choose 1-9.")
        except Exception as e:
            print("Error:", e)

if __name__ == "__main__":
    main()